function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5snFXHG8LME":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

